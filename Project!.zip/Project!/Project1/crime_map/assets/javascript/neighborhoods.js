var neighborhood = [
  {
    name: 'SEAVIEW',
    zip: '98136'
  },
  {
    name: 'MOUNT BAKER',
    zip: '98144'
  },
  {
    name: 'SLU/CASCADE',
    zip: '98109'
  },
  {
    name: 'UNIVERSITY',
    zip: '98195'
  },
  {
    name: 'MAGNOLIA',
    zip: '98199'
  },
  {
    name: 'DOWNTOWN COMMERCIAL',
    zip: '98101'
  },
  {
    name: 'CAPITOL HILL',
    zip: '98102'
  },
  {
    name: 'BELLTOWN',
    zip: '98121'
  },
  {
    name: 'SODO',
    zip: '98154'
  },
  {
    name: 'SODO',
    zip: '98164'
  },
  {
    name: 'ALKI',
    zip: '98116'
  },
  {
    name: 'HIGH POINT',
    zip: '98126'
  },
  {
    name: 'BALLARD',
    zip: '98107'
  },
  {
    name: 'QUEEN ANNE',
    zip: '98119'
  },
  {
    name: 'BITTERLAKE',
    zip: '98133'
  },
  {
    name: 'GEORGETOWN',
    zip: '98108'
  },
  {
    name: 'RAINIER VIEW',
    zip: '98178'
  },
  {
    name: 'UNIVERSITY',
    zip: '98105'
  },
  {
    name: 'LAKECITY',
    zip: '98155'
  },
  {
    name: 'GREENWOOD',
    zip: '98177'
  },
  {
    name: 'FREMONT',
    zip: '98103'
  },
  {
    name: 'PIONEER SQUARE',
    zip: '98104'
  },
  {
    name: 'CENTRAL AREA/SQUIRE PARK',
    zip: '98112'
  },
  {
    name: 'ROOSEVELT/RAVENNA',
    zip: '98115'
  },
  {
    name: 'LAKEWOOD/SEWARD PARK',
    zip: '98118'
  },
  {
    name: 'CENTRAL AREA/SQUIRE PARK',
    zip: '98122'
  },
  {
    name: 'NORTHGATE',
    zip: '98125'
  },
  {
    name: 'DOWNTOWN COMMERCIAL',
    zip: '98134'
  },
  {
    name: 'ROXHILL/WESTWOOD/ARBOR HEIGHTS',
    zip: '98146'
  },
  {
    name: 'DELRIDGE',
    zip: '98106'
  },
  {
    name: 'BALLARD',
    zip: '98117'
  },
  {
    name: 'COMMERCIAL DUWAMISH',
    zip: '98168'
  }
];
